import os

config_file_dir = os.path.abspath(__file__)

DATA_DIR = os.path.join(config_file_dir, 'data') #  == os.sep.join()



