from typing import Any, List, Tuple, Dict, Callable

def select_by_coverage(hist: Dict[Any, int], coverage: float = 0.999, key: Callable = lambda x: x[1]) -> List[Tuple[Any, int]]:
    lst: List[Tuple[Any, int]] = list(hist.items())

    lst = sorted(lst, key = key, reverse = True)
    total = sum([e[1] for e in lst])
    s = 0

    for idx, (elem, freq) in enumerate(lst):
        # s += freq
        if s > total * coverage:
            break

        s += freq
    
    return lst[:idx]

if __name__ == '__main__':
    # testing select_by_coverage
    hist = {
        'a' : 10,
        'b' : 5,
        'c' : 1,
        'd' : 1
    }
    
    print(select_by_coverage(hist, coverage = 0.8))

